﻿from scapy.all import *
from scapy.layers.inet import IP, ICMP
a = IP()
a.dst = '10.0.2.5'
b = ICMP()
p = a/b
send(p)
