#!/usr/bin/env python3
from scapy.all import *
from scapy.layers.inet import IP, ICMP

a = IP()
a.dst = '8.8.8.8'
for i in range(0,10):
    a.ttl = i
    b =ICMP()
    send(a/b)
