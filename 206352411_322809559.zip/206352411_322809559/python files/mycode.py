#view mycode.py
#!/usr/bin/env python3
from scapy.all import *
from scapy.layers.inet import IP

a = IP()
a.show()
# python3 mycode.py
###[ IP ]###
version = 4
ihl = None
...
# Make mycode.py executable (another way to run python programs)
# chmod a+x mycode.py
# mycode.py
